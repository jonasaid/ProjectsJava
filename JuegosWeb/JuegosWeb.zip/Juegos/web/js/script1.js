function Saluda(){
    alert("Cuidado");
}

