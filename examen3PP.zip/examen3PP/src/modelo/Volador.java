package modelo;


public interface Volador {
    double gravedad = 9.81;
    
    public boolean volar();
    
    public String despegar();
            
}
